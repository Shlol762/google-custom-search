__version__ = "0.1.3"

from .search import custom_search
from .object import result