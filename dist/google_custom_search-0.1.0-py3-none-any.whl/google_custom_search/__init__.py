__version__ = "0.1.0"

from .search import custom_search
from .object import result